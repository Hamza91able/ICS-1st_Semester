#include <stdio.h>
#include<conio.h>
#include <math.h>
int main()
{
	printf("\t\t\t<<<WELCOME TO DECIMAL TO BINARY CONVERTER>>>\n\n");
    long long binNum = 0;
    int num, remainder, i = 1;
    printf(" ENTER A DECIMAL NUMBER \n ");
    scanf("%d", &num);

    while (num!=0)
    {
        remainder = num%2;
        num/= 2;
        binNum += remainder*i;
        i *= 10;
    } printf("Converted number into BINARY IS %lld\n", binNum);
    return 0;
}
