
#include<stdio.h>
#include<conio.h>
#inclUde<math.h>
#include<string.h>
void Binary_to_Decimal();
void Binary_to_Octal();
void Binary_to_Hexa-decimal();
void Decimal_to_Binary();
void Decimal_to_Octal();
void Decimal_to_Hexa-deciaml();
void Octal_to_Binary();
void Octal_to_Decimal();
void Octal_to_Hexa-decimal();
void Hexa-decimal_to_Decimal();
void Hexa-decimal_to_Binary();
void Hexa-decimal_to_octal();

int main()
{
	int opt;
	char choice;
	
	printf("\t\t <<<< WELLCOME TO THE NUMBER SYSTEM CONVERTER >>>> \n\n");

	do
	{
		printf(" Press [1]: BINARY TO DECIMAL CONVERSION \n");
		printf(" Press [2]: BINARY TO OCTAL CONVERSION \n)");
	    printf(" Press [3]: BINARY TO HEXA-DECIMAL CONVERSION \n");
	    printf(" Press [4]: DECIMAL TO BINARY CONVERSION \n");
	    printf(" Press [5]: DECIMAL TO OCTAL CONVERSION \n");
	    printf(" Press [6]: DECIMAL TO HEXA-DECIMAL CONVERSION \n");
	    printf(" Press [7]: OCTAL TO BINARY CONVERSION \n");
	    printf(" Press [8]: OCTAL TO DECIMAL CONVERSION \n");
	    printf(" Press [9]: OCTAL TO HEXA DECIMAL CONVERSION \n");
	    printf(" Press [10]: HEXA-DECIMAL TO DECIMAL CONVERSION \n");
	    printf(" Press [11]: HEXA-DECIMAL TO BINARY CONVERSION \n");
	    printf(" Press [12]: HEXA-DECIMAL TO OCTAL CONVERSION \n");
	    
	    scanf("%d", &op);
	    OP=getch();
	    switch(op)
	    {
	      case 1:
	        Binary_to_Decimal();
	        break;
	      case 2:
	      	Binary_to_Octal();
	      	break;
	      case 3:
	        Binary_to_Hexa-decimal();
	        break;
	      case 4:
	      	Decimal_to_Binary();
	      	break;
	      case 5:
	      	Decimal_to_Octal();
	      	break;
	      case 6:
	      	Decimal_to_Hexa-deciaml();
	      	break;
	      case 7:
	      	Octal_to_Binary();
	      	break;
	      case 8:
	      	Octal_to_Decimal();
	      	break;
		  case 9:
		  	Octal_to_Hexa-decimal();
		  	break;
		  case 10:
		  	Hexa-decimal_to_Decimal();
		  	break;
		  case 11:
		  	Hexa-decimal_to_Binary();
		  	break;
		  case 12:
		  	Hexa-decimal_to_octal();
		  	break;
		default; 
		    printf (" << YOU HAVE ENTERED A WRONG SELECTION >>\n\n");
		}
		printf("<<TO USE THIS CONVERTER AGAIN PRESS Y OR PRESS N TO LEAVE>>\n");
		Choice=getch();
	}
 while (choice=='y' || choice=='Y')
 return 0;
}

void Binary_to_Decimal()
{
	printf("\t\t << WELCOME TO THE BINARY TO DECIMAL CONVERTER>>\n\n");
long long num;
    int decNum=0, i=0, remainder;
    printf("Enter a binary number: ");
    scanf("%lld", &num);
    while (num!=0)
    {
        remainder = num%10;
        num /= 10;
        decNum += remainder*pow(2,i); // it can also be wrutten as decNum = decNum +remainder*pow(2,i) //
        ++i;
    }
    printf("converted number in decimal is %d\n", decNum );
    return 0;
}

